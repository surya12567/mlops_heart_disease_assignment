Save your genuine screenshots here and reference them in the final report.
Suggested evidence:
1. 01_dataset_and_eda.png — dataset dimensions / EDA output
2. 02_class_balance.png — target distribution
3. 03_correlation_heatmap.png — correlation plot
4. 04_mlflow_runs.png — both experiment runs and metrics
5. 05_pytest_ruff.png — passing tests and lint output
6. 06_github_actions.png — successful workflow run and uploaded artifacts
7. 07_docker_build.png — successful Docker build
8. 08_api_docs.png — FastAPI /docs
9. 09_prediction_response.png — actual /predict response using a sample payload
10. 10_metrics_endpoint.png — /metrics output
11. 11_kubernetes_resources.png — pods and service
12. 12_deployed_health.png — verified health response after deployment
Do not fabricate screenshots or use sample images as proof of a real deployment.
